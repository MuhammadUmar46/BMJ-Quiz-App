const firebaseConfig = {
    apiKey: "AIzaSyAE9cnjXNpQVLs9-SXKoBYxyvhPwXqQuPY",
    authDomain: "quizapp-da096.firebaseapp.com",
    projectId: "quizapp-da096",
    storageBucket: "quizapp-da096.appspot.com",
    messagingSenderId: "345698678218",
    appId: "1:345698678218:web:e1f9087c175db4cafccb33",
    measurementId: "G-SKYQCXK9LP"
};

 // Initialize Firebase
 const app = firebase.initializeApp(firebaseConfig);

function check(){
    var score = 0;
    var name = document.getElementById('name')
    var right_ans_1 = document.getElementById('right-ans-1')
    var right_ans_2 = document.getElementById('right-ans-2')
    var right_ans_3 = document.getElementById('right-ans-3')

    if( right_ans_1.checked == true){
        score++
    }
    if ( right_ans_2.checked == true){
        score++
    }
    if ( right_ans_3.checked == true){
        score++
    }
    if(name.value === ''){
      alert('Please Enter Your Name')
    }
    else{
        firebase.database().ref('name').set(name.value)

        firebase.database().ref('score').set(score)
        document.write('your score is'+ score +' /3')
    }
    
}